/*
cblsrv is covered by the LGPL:

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the
Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.

Copyright (c) 2006 Zoltan Csizmadia <zoltan_csizmadia@yahoo.com>
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef _CABLE_H_INCLUDED_
#define _CABLE_H_INCLUDED_

#include "bits.h"

// TAP states
#define TAPSTATE_RESET      0x00
#define TAPSTATE_IDLE       0x01
#define TAPSTATE_SELECTDR   0x02
#define TAPSTATE_CAPTUREDR  0x03
#define TAPSTATE_SHIFTDR    0x04
#define TAPSTATE_EXIT1DR    0x05
#define TAPSTATE_PAUSEDR    0x06
#define TAPSTATE_EXIT2DR    0x07
#define TAPSTATE_UPDATEDR   0x08
#define TAPSTATE_IRSTATES   0x09
#define TAPSTATE_SELECTIR   0x09
#define TAPSTATE_CAPTUREIR  0x0A
#define TAPSTATE_SHIFTIR    0x0B
#define TAPSTATE_EXIT1IR    0x0C
#define TAPSTATE_PAUSEIR    0x0D
#define TAPSTATE_EXIT2IR    0x0E
#define TAPSTATE_UPDATEIR   0x0F

class cable
{
public:
    cable();
    virtual ~cable();

public:
    virtual int open() = 0;
    virtual int close() = 0;

    virtual int get_desc(char* desc, int len) = 0;

    virtual int set_option(const char* name, const char* value);
    virtual int get_option(const char* name, char* value, int len);
    
    virtual int set_tms(int) = 0;
    virtual int set_tck(int) = 0;
    virtual int pulse_tck(int) = 0;
    virtual int shift_tms(u32 tms_seq, int count) = 0;
    virtual int shift(int num_bits, void* wbuff, void* rbuff, int last) = 0;

public:
    int tms_transition(int state_from, int state_to, u32* tms_seq);

public:
    virtual int write(int mode, bits& wbuff, bits& wmask, bits& cmp_rbuff, bits& cmp_rmask);

public:
    bits& get_last_rbuff();

public:
    cable* factory(const char* addr);

protected:
    bits hir;
    bits hdr;
    bits tir;
    bits tdr;
    bits last_rbuff;
};

#endif
