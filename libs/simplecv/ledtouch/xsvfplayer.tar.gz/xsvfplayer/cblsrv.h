/*
cblsrv is covered by the LGPL:

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the
Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.

Copyright (c) 2006 Zoltan Csizmadia <zoltan_csizmadia@yahoo.com>
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef _CBLSRV_H_INCLUDED_
#define _CBLSRV_H_INCLUDED_

#include "platform.h"

#define VERSION_MAJOR           0
#define VERSION_MINOR           2

#define CBLSRV_DEFAULT_PORT        2000

#define ACK_OK                  1
#define ACK_ERR                 0

#define MSG_COMMANDS            0x01
#define MSG_SET_CABLE_MODE      0x03
#define MSG_CLOSE_CABLE         0x04
#define MSG_GET_INFO            0x05
//#define MSG_CHECK_SERVER      0x0C // Get speed table ???
#define MSG_CHECK_SERVER        0x70

#define CMD_DONE                0x02
#define CMD_SET_CABLE_OPTION    0x06
#define CMD_GET_CABLE_OPTION    0x07
#define CMD_IS_CONNECTED        0x11
#define CMD_READ                0x20
#define CMD_WRITE               0x21
#define CMD_SET_PIN             0x25
#define CMD_PULSE_PIN           0x26
#define CMD_START_OPERATION     0x30
#define CMD_NAVIGATE_TAP        0x31
#define CMD_WAIT_TIME           0x35
#define CMD_WAIT_TCK            0x37

#define WRITE_SHIFTDR           0
#define WRITE_SHIFTIR           16
#define WRITE_SHIFT             32
#define WRITE_SHIFT_LAST        48
#define WRITE_SHIFTDR_LAST      64
#define WRITE_SHIFTIR_LAST      80
//#define WRITE_???             96
//#define WRITE_???             112
#define WRITE_TDR               128
#define WRITE_TIR               144
#define WRITE_HDR               160
#define WRITE_HIR               176

class cable;

typedef struct 
{
    int server;
    int client;
    
    int exit_program;
    int trace_level;
    u16 server_port;

    u8 cable_mode;
    char cable_name[256];
    int cable_port;
    int cable_speed;
    char cable_type[256];

    cable* current_cable;
} Globals;
extern Globals g;

#endif
