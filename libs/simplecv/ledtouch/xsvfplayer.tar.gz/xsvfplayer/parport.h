/*
cblsrv is covered by the LGPL:

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the
Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.

Copyright (c) 2006 Zoltan Csizmadia <zoltan_csizmadia@yahoo.com>
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

changes by thomas.pototschnig@gmx.de:
	fixed bitmasks in get_tck_mask(), get_tms_mask() and get_tdi_mask()

*/

#ifndef _PARPORT_H_INCLUDED_
#define _PARPORT_H_INCLUDED_

// Define this if you want to support parport access by direct I/O
#define PARPORT_DIRECT

// Define this if you want to support parport access by /dev/parportX
#if !defined(WIN32) && !defined(__CYGWIN__)
//#define PARPORT_PPDEV
#endif

#include <stdio.h>
#include "cable.h"

class parport : public cable
{
public:
    parport(const char* addr);
    virtual ~parport();

public:
    virtual int open();
    virtual int close();

    virtual int get_desc(char* desc, int len) = 0;

    virtual int get_tdo();
    virtual int set_tdi(int b);
    virtual int set_tms(int);
    virtual int set_tck(int);
    virtual int pulse_tck(int);
    
    virtual int shift_tms(u32 tms_seq, int count);
    virtual int shift(int num_bits, void* wbuff, void* rbuff, int last);

protected:
    virtual u8 get_tck_mask() = 0;
    virtual u8 get_tms_mask() = 0;
    virtual u8 get_tdi_mask() = 0;
    virtual u8 get_tdo_mask() = 0;

protected:
    int set_data(u8 data);
    int set_control(u8 data);
    int get_status();

protected:
    char addr[256];
#ifdef PARPORT_DIRECT
    u16 ioaddr;
#endif
#ifdef PARPORT_PPDEV
    int fd;
#endif
    u8 pp_data;
};

//
// Xilinx Parallel III (DLC5)
//
class dlc5 : public parport  
{
public:
    dlc5(const char* addr) : parport(addr) {}
    virtual int open();
    virtual int get_desc(char* desc, int len)
    {
        return snprintf(desc, len, "Xilinx Parallel III (%s)", addr);
    }

protected:
// bugfix: see header
    virtual u8 get_tck_mask() { return /*(1 << 4) |*/ (1 << 1); }
    virtual u8 get_tms_mask() { return /*(1 << 4) |*/ (1 << 2); }
    virtual u8 get_tdi_mask() { return /*(1 << 4) |*/ (1 << 0); }
    virtual u8 get_tdo_mask() { return (1 << 4); }
};

//
// Altera ByteBlaster
//
class byte_blaster : public parport  
{
public:
    byte_blaster(const char* addr) : parport(addr) {}

    virtual int open();
    virtual int get_desc(char* desc, int len)
    {
        return snprintf(desc, len, "Altera ByteBlaster (%s)", addr);
    }

protected:
    virtual u8 get_tck_mask() { return (1 << 0); }
    virtual u8 get_tms_mask() { return (1 << 1); }
    virtual u8 get_tdi_mask() { return (1 << 6); }
    virtual u8 get_tdo_mask() { return (1 << 7); }
};


#endif
