/*
cblsrv is covered by the LGPL:

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the
Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.

Copyright (c) 2006 Zoltan Csizmadia <zoltan_csizmadia@yahoo.com>
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

changes by thomas.pototschnig@gmx.de:
	inserted dlc::open() which initializes the parport with (1<<4)
	(=tie Pin6 to high and Pin5 to low)
*/

#include "cblsrv.h"
#include "parport.h"
#include "utils.h"

#ifdef PARPORT_PPDEV
#include <sys/ioctl.h>
#include <linux/ioctl.h>
#include <linux/ppdev.h>
#endif

//
// Altera ByteBlaster
//
int byte_blaster::open()
{
    int vII = 0;
    int rc;

    rc = parport::open();
    if (rc < 0)
        return rc;

    // Check if a ByteBlaster or ByteBlasterMV
    set_data(1 << 5);
    vII = (get_status() >> 6) & 1 ? 0 : 1;
    set_data(0);
    vII &= (get_status() >> 6) & 1;
    
    // Check power supply for ByteBlaster II
    if (vII && (get_status() & (1 << 3)))
    {
        close();
        return -1;
    }
    
    // Enable ByteBlaster
    set_control(0xC);

    return 0;
}

// bugfix: see header
int dlc5::open()
{
    int rc;

    rc = parport::open();
    if (rc < 0)
        return rc;

    // Enable DLC5
    pp_data = (1<<4);
		set_data(pp_data);

    return 0;
}


//
// Base class
//

parport::parport(const char* _addr)
{
#ifdef PARPORT_DIRECT
    ioaddr = 0;
    if (_addr == NULL)
        _addr = "0x378";
#endif

#ifdef PARPORT_PPDEV
    fd = -1;
    if (_addr == NULL)
        _addr = "/dev/parport0";
#endif

    pp_data = 0;
    
    strncpy(addr, _addr, sizeof(addr));
}

parport::~parport()
{
}

int parport::open()
{
    int rc = -1;

    tracef(3, "Opening cable ...\n");

#ifdef PARPORT_DIRECT
    if (ioaddr)
        return -1;
#endif

#ifdef PARPORT_PPDEV
    if (fd != -1)
        return -1;
#endif

#ifdef PARPORT_DIRECT
    ioaddr = (u16)strtol(addr, NULL, 0);
    if (ioaddr)
    {
        if (ioaddr <= 0)
            goto cleanup;

        // Direct I/O access
        if (enable_user_mode_io() < 0)
            goto cleanup;

        rc = 0;
    }
#endif

#ifdef PARPORT_PPDEV
    if (rc < 0 && addr[0] == '/')
    {
        // Using ppdev device
        fd = ::open(addr, O_RDWR);
        if (fd < 0)
        {
            tracef(3, "Failed to open %s!\n", addr);
            goto cleanup;
        }

        if (ioctl(fd, PPEXCL) == -1 || ioctl(fd, PPCLAIM) == -1)  
        {
            tracef(3, "PPEXCL or PPCLAIM failed (%s)!\n", addr);
            goto cleanup;
        }

        rc = 0;
    }
#endif
    
    pp_data = 0;
    set_data(pp_data);

cleanup:

    if (rc)
        close();

    return rc;
}

int parport::close()
{
#ifdef PARPORT_DIRECT
    ioaddr = 0;
#endif

#ifdef PARPORT_PPDEV
    if (fd != -1)
    {
        ioctl(fd, PPRELEASE);
        ::close(fd);
        fd = -1;
    }
#endif

    tracef(3, "Cable closed.\n");

    return 0;
}

int parport::set_data(u8 data)
{
#ifdef PARPORT_DIRECT
    if (ioaddr)
    {
        outb(data, ioaddr);
        return 0;
    }
#endif

#ifdef PARPORT_PPDEV
    if (fd != -1)
        return ioctl(fd, PPWDATA, &data);
#endif
    
    return -1;
}

int parport::get_status()
{
#ifdef PARPORT_DIRECT
    if (ioaddr)
        return inb((u16)(ioaddr + 1));
#endif

#ifdef PARPORT_PPDEV
    if (fd != -1)
        return ioctl(fd, PPRSTATUS);
#endif

    return -1;
}

int parport::set_control(u8 data)
{
#ifdef PARPORT_DIRECT
    if (ioaddr)
    {
        outb(data, ioaddr);
        return 0;
    }
#endif

#ifdef PARPORT_PPDEV
    if (fd != -1)
        return ioctl(fd, PPWCONTROL, &data);
#endif

    return -1;
}

int parport::set_tdi(int b)
{
    u8 mask = get_tdi_mask();
    if (b)
        pp_data |= mask;
    else
        pp_data &= ~mask;

    return set_data(pp_data);
}

int parport::set_tms(int b)
{
    u8 mask = get_tms_mask();
    if (b)
        pp_data |= mask;
    else
        pp_data &= ~mask;

    return set_data(pp_data);
}

int parport::set_tck(int b)
{
    u8 mask = get_tck_mask();
    if (b)
        pp_data |= mask;
    else
        pp_data &= ~mask;

    return set_data(pp_data);
}

int parport::get_tdo()
{
    return (get_status() & get_tdo_mask()) ? 1 : 0;
}

int parport::pulse_tck(int count)
{
    while (count--)
    {
        set_tck(1);
        set_tck(0);
    }
    return 0;
}

int parport::shift(int num_bits, void* wbuff, void* rbuff, int last)
{
    u8 tdi_byte, tdo_byte;
    int i;
    u8* pw = (u8*)wbuff;
    u8* pr = (u8*)rbuff;

    while (num_bits)
    {
        tdi_byte = *pw++;
        tdo_byte = 0;

        for (i = 0; (num_bits && (i < 8)); i++)
        {
            num_bits--;
            if (last && !num_bits)
                // Exit Shift-DR state
                set_tms(1);

            // Set the new TDI value
            set_tdi(tdi_byte & 1);
            tdi_byte >>= 1;

            if (pr)
                // Save TDO bit
                tdo_byte |= get_tdo() << i;

            // Clock cycle
            set_tck(1);
            set_tck(0);
        }

        // Save TDO byte
        if (pr)
            *pr++ = tdo_byte;
    }

    return 0;
}

int parport::shift_tms(u32 tms_seq, int count)
{
    while (count--)
    {
        set_tms(tms_seq & 1);
        set_tck(1);
        set_tck(0);
        tms_seq >>= 1;
    }
    return 0;
}
