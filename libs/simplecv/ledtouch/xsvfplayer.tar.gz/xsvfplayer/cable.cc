/*
cblsrv is covered by the LGPL:

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the
Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.

Copyright (c) 2006 Zoltan Csizmadia <zoltan_csizmadia@yahoo.com>
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "cblsrv.h"
#include "utils.h"
#include "cable.h"

cable::cable()
{
}

cable::~cable()
{
}

int cable::set_option(const char* /*name*/, const char* /*value*/)
{
    return 0;
}

int cable::get_option(const char* /*name*/, char* /*value*/, int /*len*/)
{
    return -1;
}

int cable::tms_transition(int state_from, int state_to, u32* tms_seq)
{
    u32 seq = 0;
    int cnt = 0;
    int tms;

    if (state_to == TAPSTATE_RESET)
    {
        // If RESET, always perform TMS reset sequence to reset/sync TAPs
        seq = 0xFF;
        cnt = 5;
    }
    else 
    if ((state_to != state_from) &&
        (((state_to == TAPSTATE_EXIT2DR) && (state_from != TAPSTATE_PAUSEDR)) ||
        ((state_to == TAPSTATE_EXIT2IR ) && (state_from != TAPSTATE_PAUSEIR))))
        // Illegal TAP state_to path
        return -1;
    else
    {
        // Already in target state_to.  Do nothing except when in DRPAUSE
        // or in IRPAUSE to comply with SVF standard
        if (state_to == state_from &&
            (state_to == TAPSTATE_PAUSEDR || state_to == TAPSTATE_PAUSEIR))
        {
            seq <<= 1;
            seq |= 1;
            cnt++;
            state_from = state_to == TAPSTATE_PAUSEDR ? TAPSTATE_EXIT2DR : TAPSTATE_EXIT2IR;
        }

        // Perform TAP state_to transitions to get to the target state_to
        while (state_from != state_to)
        {
            tms = 0;
            switch (state_from)
            {
            case TAPSTATE_RESET:
                state_from = TAPSTATE_IDLE;
                break;

            case TAPSTATE_IDLE:
                tms = 1;
                state_from = TAPSTATE_SELECTDR;
                break;

            case TAPSTATE_SELECTDR:
                if (state_to >= TAPSTATE_IRSTATES )
                {
                    tms = 1;
                    state_from = TAPSTATE_SELECTIR;
                }
                else
                {
                    state_from = TAPSTATE_CAPTUREDR;
                }
                break;

            case TAPSTATE_CAPTUREDR:
                if (state_to == TAPSTATE_SHIFTDR )
                {
                    state_from = TAPSTATE_SHIFTDR;
                }
                else
                {
                    tms = 1;
                    state_from = TAPSTATE_EXIT1DR;
                }
                break;

            case TAPSTATE_SHIFTDR:
                tms = 1;
                state_from = TAPSTATE_EXIT1DR;
                break;

            case TAPSTATE_EXIT1DR:
                if (state_to == TAPSTATE_PAUSEDR )
                {
                    state_from = TAPSTATE_PAUSEDR;
                }
                else
                {
                    tms = 1;
                    state_from = TAPSTATE_UPDATEDR;
                }
                break;

            case TAPSTATE_PAUSEDR:
                tms = 1;
                state_from = TAPSTATE_EXIT2DR;
                break;

            case TAPSTATE_EXIT2DR:
                if (state_to == TAPSTATE_SHIFTDR )
                {
                    state_from = TAPSTATE_SHIFTDR;
                }
                else
                {
                    tms = 1;
                    state_from = TAPSTATE_UPDATEDR;
                }
                break;

            case TAPSTATE_UPDATEDR:
                if (state_to == TAPSTATE_IDLE)
                {
                    state_from = TAPSTATE_IDLE;
                }
                else
                {
                    tms = 1;
                    state_from = TAPSTATE_SELECTDR;
                }
                break;

            case TAPSTATE_SELECTIR:
                state_from = TAPSTATE_CAPTUREIR;
                break;

            case TAPSTATE_CAPTUREIR:
                if (state_to == TAPSTATE_SHIFTIR )
                {
                    state_from = TAPSTATE_SHIFTIR;
                }
                else
                {
                    tms = 1;
                    state_from = TAPSTATE_EXIT1IR;
                }
                break;

            case TAPSTATE_SHIFTIR:
                tms = 1;
                state_from = TAPSTATE_EXIT1IR;
                break;

            case TAPSTATE_EXIT1IR:
                if (state_to == TAPSTATE_PAUSEIR )
                {
                    state_from = TAPSTATE_PAUSEIR;
                }
                else
                {
                    tms = 1;
                    state_from = TAPSTATE_UPDATEIR;
                }
                break;

            case TAPSTATE_PAUSEIR:
                tms = 1;
                state_from = TAPSTATE_EXIT2IR;
                break;

            case TAPSTATE_EXIT2IR:
                if (state_to == TAPSTATE_SHIFTIR )
                {
                    state_from = TAPSTATE_SHIFTIR;
                }
                else
                {
                    tms = 1;
                    state_from = TAPSTATE_UPDATEIR;
                }
                break;

            case TAPSTATE_UPDATEIR:
                if (state_to == TAPSTATE_IDLE )
                {
                    state_from = TAPSTATE_IDLE;
                }
                else
                {
                    tms = 1;
                    state_from = TAPSTATE_SELECTDR;
                }
                break;

            default:
                state_from = state_to;
                return -1;
            }

            seq |= (tms << cnt);
            cnt++;
        }
    }

    *tms_seq = seq;

    return cnt;
}

bits& cable::get_last_rbuff()
{
    return last_rbuff;
}

int cable::write(int mode, bits& wbuff, bits& /*wmask*/, bits& cmp_rbuff, bits& /*cmp_rmask*/)
{
    int last = 0;
    u32 pre_tms = 0;
    int pre_tms_count = 0;
    bits* ph = NULL;
    bits* pt = NULL;
    
    last_rbuff.clear();
        
    if (cmp_rbuff.get_len() != 0 && cmp_rbuff.get_len() != wbuff.get_len())
        return -1;
    
    if (last_rbuff.init(wbuff.get_len()) < 0)
    {
        tracef(1, "last_rbuff alloc failed!\n");
        return -1;
    }
 
    // TIR, TDR, HIR, HDR
    switch (mode)
    {
    case WRITE_HDR:
        return hdr.init(wbuff);

    case WRITE_HIR:
        return hir.init(wbuff);
        break;

    case WRITE_TDR:
        return tdr.init(wbuff);
        break;

    case WRITE_TIR:
        return tir.init(wbuff);
    }

    //
    // SHIFTDR, SHIFTIR state change
    // We assume the JTAG device is in IDLE state
    //
    if (mode == WRITE_SHIFTDR || mode == WRITE_SHIFTDR_LAST)
        pre_tms_count = tms_transition(TAPSTATE_IDLE, TAPSTATE_SHIFTDR, &pre_tms);
    else
    if (mode == WRITE_SHIFTIR || mode == WRITE_SHIFTIR_LAST)
        pre_tms_count = tms_transition(TAPSTATE_IDLE, TAPSTATE_SHIFTIR, &pre_tms);

    if (pre_tms_count)
        shift_tms(pre_tms, pre_tms_count);
    
    // TMS must go high at last bit
    if (mode == WRITE_SHIFTDR_LAST || mode == WRITE_SHIFTIR_LAST || mode ==WRITE_SHIFT_LAST)
        last = 1;

    // Header
    if ((mode == WRITE_SHIFTIR || mode == WRITE_SHIFTIR_LAST) && hir.get_len())
        ph = &hir;
    else
    if ((mode == WRITE_SHIFTDR || mode == WRITE_SHIFTDR_LAST) && hdr.get_len())
        ph = &hdr;

    // Trailer
    if (last)
    {
        if (mode == WRITE_SHIFTIR_LAST && tir.get_len())
            pt = &tir;
        else
        if (mode == WRITE_SHIFTDR_LAST && tdr.get_len())
            pt = &tdr;
    }

    // Shift Header
    if (ph)
        shift(ph->get_len(), ph->get_data(), NULL, 0);

    // Shift TDO/TDI
    shift(
        wbuff.get_len(), 
        wbuff.get_data(), 
        cmp_rbuff.get_len() ? last_rbuff.get_data() : NULL, 
        last && pt == NULL);

    // Shift Trailer
    if (last && pt)
        shift(pt->get_len(), pt->get_data(), NULL, 1);

    // ???
    // Compare buffers if read buffer and mask are provided
    // ???
    /*
    if (cmp_rbuff.get_len())
    {
        int rlen_bytes, i, rmask_len_bytes;
        u8 mask8;
        
        rlen_bytes = cmp_rbuff.get_len_bytes();
        rmask_len_bytes = cmp_rmask.get_len_bytes();
    
        for (i = 0; i < rlen_bytes; i++)
        {
            mask8 = rmask_len_bytes ? cmp_rmask[i] : (u8)0xFF;
            if (!mask8)
                continue;
            if ((last_rbuff[i] & mask8) != (cmp_rbuff[i] & mask8))
                // Mismatch
                return -1;
        }
    }
    */
    
    return 0;
}
