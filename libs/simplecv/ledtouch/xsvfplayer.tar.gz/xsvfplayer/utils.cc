/*
cblsrv is covered by the LGPL:

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the
Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.

Copyright (c) 2006 Zoltan Csizmadia <zoltan_csizmadia@yahoo.com>
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "cblsrv.h"
#include "utils.h"

u8 yes8 = 1;
u8 no8 = 0;

u8 trace_level = 3;

//
// Trace
//

void tracef(int level, const char* format, ...)
{
    va_list args;

    if (level > trace_level)
        return;

    va_start(args, format);
    vprintf(format, args);
    va_end(args);
}

//
// User mode I/O access
//

#ifdef WIN32
u8 inb(u16 port)
{
    u8 rc;
    __asm mov dx,port
    __asm in al, dx
    __asm mov rc, al
    return rc;
}

void outb(u8 data, u16 port)
{
    __asm mov dx,port
    __asm mov al, data
    __asm out dx, al
}
#endif

int enable_user_mode_io()
{
#ifdef WIN32
    HANDLE h;
    
    h = CreateFile(
            "\\\\.\\giveio",
            GENERIC_READ,
            0,
            NULL,
            OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL,
            NULL);
    if (h != INVALID_HANDLE_VALUE)
    {
        // Giveio activated successfully
        CloseHandle(h);
        return 0;
    }
#else
    if (iopl(3) == 0)
        // Success
        return 0;
#endif

    tracef(1, "Failed to enable user mode I/O access!\n");

    return -1;
}


//
// Sleep
//

void sleep_us(int us)
{
#ifdef WIN32
    Sleep((us + 999)/1000);
#else
    usleep(us);
#endif
}
