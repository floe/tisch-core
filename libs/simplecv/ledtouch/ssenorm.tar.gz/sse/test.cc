#include <sys/time.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ItNorm.h"
#include <cv.h>
#include <highgui.h>
#include <unistd.h>

struct timeval tv1, tv2;
struct timezone tz1, tz2;
long totalT;

extern "C" void _calcMinMax(float* src, float* min, float* max);
extern "C" void _normalizeImg(float* img, float rangeMin, float rangeMax);
extern "C" int _convoluteX(float* kernel, int ksize, float ksum, float* src, float* dst);
extern "C" int _convoluteY(float* kernel, int ksize, float ksum, float* src, float* dst);
extern "C" void _clampZero(float* img, float* dst);
extern "C" void _calcDiff(float* src, float* inh, float* exc);

ItNorm* pN;

float img[48*32] __attribute__((__aligned__(16)));
float dst[48*32] __attribute__((__aligned__(16)));
float dst2[48*32] __attribute__((__aligned__(16)));
float m_tmp1[48*32] __attribute__((__aligned__(16)));
float m_imgExc[48*32] __attribute__((__aligned__(16)));
float m_imgInh[48*32] __attribute__((__aligned__(16)));

void iterativeNormalize(float* img, float* dst, int numIter, float min, float max)
{
	_clampZero(img, dst);

  	if (min || max)
		_normalizeImg(dst, min,max);

	for (int i=0;i<numIter;i++)
	{
		_convoluteX((float*) pN->m_gExc, pN->m_gExcSize, pN->m_gExcSum, dst,m_tmp1);
		_convoluteY((float*) pN->m_gExc, pN->m_gExcSize, pN->m_gExcSum, m_tmp1,m_imgExc);
		_convoluteX((float*) pN->m_gInh, pN->m_gInhSize, pN->m_gInhSum, dst,m_tmp1);
		_convoluteY((float*) pN->m_gInh, pN->m_gInhSize, pN->m_gInhSum, m_tmp1,m_imgInh);
		_calcDiff(dst,m_imgInh,m_imgExc);
	}
	_normalizeImg(dst, 0.0f, 1.0f);
}


int main()
{
	IplImage* imgData = cvCreateImage(cvSize(48,32), IPL_DEPTH_8U, 1);
	imgData = cvLoadImage("ohne_normit.bmp",1); 

	pN = new ItNorm(48,32);
	


	memset(img,0,sizeof(img));
	memset(dst,0,sizeof(dst));
	memset(dst2,0,sizeof(dst));

	for (int i=0;i<48*32;i++)
	{
		unsigned char c = imgData->imageData[i];
		img[i] = (float) c / 255.0f;
	}

	_normalizeImg(img,0.0f,1.0f);
	
	int repeatNum = 1000;
	gettimeofday(&tv1, &tz1);
	for (int z=0;z<repeatNum;z++)
	{
		iterativeNormalize(img, dst, 3, 0.0f, 10.0f);
//		pN->iterativeNormalize(img,dst2,3,0.0f,10.0f);
	}
	gettimeofday(&tv2, &tz2);
	totalT = (tv2.tv_sec - tv1.tv_sec) * 1000000 + (tv2.tv_usec - tv1.tv_usec);







//	_convoluteX((float*) pN->m_gInh, pN->m_gInhSize, pN->m_gInhSum, (float*) img, (float*) dst);
//	pN->convoluteY((float*) pN->m_gInh, pN->m_gInhSize, pN->m_gInhSum, (float*) img, (float*) dst2);

	float averageT = ((float)totalT) / ((float)repeatNum);



	
	for (int i=0;i<48*32;i++)
	{
		printf("%d - %08X %.6f %.6f\n",i,(int) *((int*) &dst[i]), dst[i],dst2[i]);
	}
	printf("%.3fus",averageT);

	return 0;
}
